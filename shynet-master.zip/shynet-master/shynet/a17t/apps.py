from django.apps import AppConfig


class A17TConfig(AppConfig):
    name = "a17t"
